import os
import platform

CURRENT_PLATFORM = platform.system()
IS_UNIX = CURRENT_PLATFORM == 'Linux' or CURRENT_PLATFORM == 'Darwin'

def get_python_executable(env_dir: str) -> str:
    if IS_UNIX: # For Unix or MacOS
        return os.path.join(env_dir, 'bin', 'python')
    else: # For Windows
        return os.path.join(env_dir, 'Scripts', 'python.exe')