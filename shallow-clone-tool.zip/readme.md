# Shallow Clone Downloader

## 📦 Installation
Run the following command inside the project directory
```bash
python install.py
```

## 🚀 Launch the Web Interface
```bash
python run.py
```