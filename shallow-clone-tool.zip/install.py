import venv
import os
import subprocess
from utils.paths import get_python_executable

def venv_setup(env_dir: str = '.venv', verbose: bool = False, install_req: bool = True, req_filename: str = 'requirements.txt') -> None:
    env_dir = os.path.join(os.getcwd(), env_dir)

    # Create virtual Python environment
    print('Creating Python virtual environment...')
    venv.create(env_dir=env_dir, with_pip=True)

    # Get Python exectuable from virtual environment
    python_executable = get_python_executable(env_dir=env_dir)

    # Install requirements
    if install_req:
        print(f'Installing requirements from "{req_filename}"...')
        if verbose:
            subprocess.check_call([python_executable, '-m', 'pip', '--disable-pip-version-check', 'install', '-r', req_filename])
        else:
            subprocess.check_call([python_executable, '-m', 'pip', '--disable-pip-version-check', 'install', '-r', req_filename, '-q'])

    print('Python virutal environment setup complete!')

if __name__ == "__main__":
    venv_setup()