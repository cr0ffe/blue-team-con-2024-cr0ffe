import subprocess
import platform
import os
from utils.paths import get_python_executable

FILENAME = "web-interface.py"

def run_in_venv(python_file: str, env_dir: str = '.venv'):
    
    # Get Python exectuable from virtual environment
    python_executable = get_python_executable(env_dir=env_dir)

    subprocess.check_call([python_executable, '-m', 'streamlit', 'run', python_file])

if __name__ == '__main__':
    run_in_venv(python_file=FILENAME)