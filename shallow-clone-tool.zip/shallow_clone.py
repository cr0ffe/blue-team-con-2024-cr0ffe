import os
import shutil
import subprocess
from pathlib import Path
import shutil

class ShallowCloneJutsu():
    def __init__(self, url: str, separator: str = '/tree', downloads_dir: str = 'downloads'):
        self._downloads_dir_path = os.path.join(os.getcwd(), downloads_dir)

        split_url = url.split('/tree')
        # ['https://github.com/elastic/elasticsearch', '/main/docs/reference/query-dsl']

        self._git_url = f"{split_url[0]}.git"
        # 'https://github.com/elastic/elasticsearch.git'

        folder_path = split_url[1]
        # '/main/docs/reference/query-dsl'

        shallow_clone_dir = Path(folder_path).parts[-1]
        # 'query-dsl'
        
        self._branch = Path(folder_path).parts[1]
        # 'main'

        self._shallow_clone_dir = os.path.join(self._downloads_dir_path, shallow_clone_dir)
        # '.../downloads/query-dsl'

        self._to_remove = os.path.join(self._shallow_clone_dir, Path(folder_path).parts[2])
        # '.../downloads/docs'

        # TODO: Use Path module instead, it is cleaner to implement
        self._wildcarded_path = f"{'/'.join(folder_path.split('/')[2:])}/*"
        # 'docs/reference/query-dsl/*'

        sparse_info_path = os.path.join(self._shallow_clone_dir, '.git', 'info')
        Path(sparse_info_path).mkdir(parents=True, exist_ok=True)

        self._sparse_checkout_path = os.path.join(sparse_info_path, 'sparse-checkout')
        # '.../downloads/query-dsl/.git/info/sparse-checkout'

    def cleanup_git(self):
        """removes the .git directory within the shallow cloned dir where it was initialized
        """
        try:
            subprocess.check_call(['rm', '-rf', '.git'], cwd=self._shallow_clone_dir)
        except FileNotFoundError:
            pass

    def git_init(self):
        """Initialize an empy git repo
        """
        subprocess.check_call(['git', 'init', self._shallow_clone_dir])

    def git_add_remote(self):
        """Set the target repo as origin
        """
        subprocess.check_call(['git', 'remote', 'add', 'origin', self._git_url], cwd=self._shallow_clone_dir)

    def git_sparse_config(self):
        """Enable sparse checkout
        """
        subprocess.check_call(['git', 'config', 'core.sparseCheckout', 'true'], cwd=self._shallow_clone_dir)

    def configure_sparse(self):
        """Download everything in target dir in the target git
        """
        with open(self._sparse_checkout_path, 'w') as file:
            file.write(self._wildcarded_path)

    def git_fetch(self):
        """Fetch files
        """
        subprocess.check_call(['git' , 'fetch', '--depth=1', 'origin', self._branch], cwd=self._shallow_clone_dir)

    def git_checkout(self):
        """Checkout main branch
        """
        subprocess.check_call(['git', 'checkout',  self._branch], cwd=self._shallow_clone_dir)

    def collaspe_nested(self):
        try:
            for root, dirs, files in os.walk(self._shallow_clone_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    shutil.move(file_path, self._shallow_clone_dir)
        except shutil.Error as e:
            pass
            
    def cleanup_empty(self):
        try:
            shutil.rmtree(self._to_remove)
        except FileNotFoundError:
            pass

if __name__ == '__main__':
    test = ShallowCloneJutsu("https://github.com/elastic/elasticsearch/tree/main/docs/reference/query-dsl")
    test.cleanup_git()
    test.git_init()
    test.git_add_remote()
    test.git_sparse_config()
    test.configure_sparse()
    test.git_fetch()
    test.git_checkout()
    test.cleanup_git()
    test.collaspe_nested()
    test.cleanup_empty()