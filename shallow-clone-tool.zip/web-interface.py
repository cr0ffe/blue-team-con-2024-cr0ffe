import streamlit as st
from shallow_clone import ShallowCloneJutsu

def download_shallow_clone(url: str):
    with st.status("Processing request...", expanded=True) as status:
        naruto = ShallowCloneJutsu(url=url)
        naruto.cleanup_git()

        st.write("Initializing GIT")
        naruto.git_init()

        st.write("Adding Remote Repo")
        naruto.git_add_remote()

        st.write("Configuring Sparse Checkout")
        naruto.git_sparse_config()
        naruto.configure_sparse()
        
        st.write("Fetching Files")
        naruto.git_fetch()
        naruto.git_checkout()

        st.write("Cleaning GIT")
        naruto.cleanup_git()

        st.write("Collapsing Nested Folders")
        naruto.collaspe_nested()
        naruto.cleanup_empty()

        status.update(
            label="Shallow clone complete!", state="complete", expanded=False
        )

def main():
    with st.form(key="form1"):
        url = st.text_input("Url")
        submitted = st.form_submit_button(label="submit")

    if submitted:
        download_shallow_clone(url)

if __name__ == '__main__':
    main()